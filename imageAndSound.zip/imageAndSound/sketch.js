console.log("js is linked!");

function setup(){   
    let cnv = createCanvas(400, 400);
    cnv.parent("canvasWrapper");
    
}

function draw(){
    background(0);
}